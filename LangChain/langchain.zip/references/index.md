# Langchain Documentation Index

## Categories

### Core Components
**File:** `core_components.md`
**Pages:** 3

### Getting Started
**File:** `getting_started.md`
**Pages:** 2

### Other
**File:** `other.md`
**Pages:** 1
